'''---------------------------------------------------------------------------
Dev:MFeliciano
 1) Create a new program that asks the user to input 2 numbers then prints out
 the sum, difference, product, and quotient.
---------------------------------------------------------------------------'''

#User input first value
strN1 = input('Enter the first number: ')

#User input second value
strN2 = input('Enter the second number: ')

#Convert to float and sum
fltSum = float(strN1) + float(strN2)

#Convert to float and subtract
fltDif = float(strN1) - float(strN2)

#Convert to float and multiply
fltPrd = float(strN1) * float(strN2)

#Convert to float and divide
fltQuo = float(strN1) / float(strN2)

#Print results
print('The sum of', strN1, 'and', strN2, 'is:', fltSum);
print('The difference between', strN1, 'and', strN2, 'is:', fltDif)
print('The product of', strN1, 'and', strN2, 'is:', fltPrd)
print('The quotient of', strN1, 'and', strN2, 'is:', fltQuo)

