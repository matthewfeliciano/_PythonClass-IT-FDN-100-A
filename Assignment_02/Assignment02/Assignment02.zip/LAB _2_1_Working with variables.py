'''-------------------------------------------------------
Dev:MFeliciano
LAB 2-1: Working with variables
1)Create a script using IDLE that add two numbers
together and then print the answers to the screen.
-------------------------------------------------------'''

#User input first value
strNumber1 = input('Enter the first number: ')
#User input second value
strNumber2 = input('Enter the second number: ')
#Convert to float and sum
fltSum = float(strNumber1) + float(strNumber2)
#Print result
print('The sum of', strNumber1, 'and', strNumber2, 'is: ', fltSum)
